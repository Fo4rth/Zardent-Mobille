<?php 

$conn= new mysqli('localhost','root','','crms_db')or die("Could not connect to mysql".mysqli_error($con));
