package com.example.group1

object EndPoints {
    private val URL_ROOT = "https://developers.aris-gail.com/21221ST_CS3101_G1/WebApi/v1/?op="
    val URL_ADD_USER = URL_ROOT + "addUsers"
    val URL_LOGIN_USER = URL_ROOT + "loginuser"
    val URL_ADD_REPORTS = URL_ROOT + "addreports"

}