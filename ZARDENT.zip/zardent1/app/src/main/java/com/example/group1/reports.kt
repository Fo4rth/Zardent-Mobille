package com.example.group1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Spinner
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.provider.MediaStore
import android.widget.*
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import org.json.JSONException
import org.json.JSONObject


class reports : AppCompatActivity() {

    private var hazards: Spinner? = null
    private var subcategory: Spinner? = null
    private var barangay: Spinner? = null
    private var city: Spinner? = null
    private var editTexthouseno: EditText? = null
    private var editTextdetails: EditText? = null

    lateinit var btnsubmit : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports)

        val btnsubmit = findViewById<Button>(R.id.btnsubmit)

        btnsubmit.setOnClickListener {
            hazards = findViewById<TextView>(R.id.typeofhazard) as Spinner?
            subcategory = findViewById<TextView>(R.id.subcategory) as Spinner?
            barangay = findViewById<TextView>(R.id.brgy) as Spinner?
            city = findViewById<TextView>(R.id.city) as Spinner?
            editTexthouseno = findViewById<TextView>(R.id.houseNo) as EditText?
            editTextdetails = findViewById<TextView>(R.id.hazardDetails) as EditText?

            val hazards = hazards?.selectedItem.toString()
            val subcategory = subcategory?.selectedItem.toString()
            val barangay = barangay?.selectedItem.toString()
            val city = city?.selectedItem.toString()
            val houseNo = editTexthouseno?.text.toString()
            val textDetails = editTextdetails?.text.toString()


            //creating volley request
            val stringRequest = object : StringRequest(
                Request.Method.POST, EndPoints.URL_ADD_REPORTS,
                Response.Listener<String> { response ->
                    try {
                        val obj = JSONObject(response)
                        Toast.makeText(
                            applicationContext,
                            obj.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->
                    Toast.makeText(
                        applicationContext,
                        volleyError.message,
                        Toast.LENGTH_LONG
                    ).show()
                }) {
                @Throws(AuthFailureError::class)
                override fun getParams(): Map<String, String> {
                    val params = HashMap<String, String>()
                    params["category"] = hazards
                    params["subcategory"] = subcategory
                    params["complaintType"] = barangay
                    params["state"] = city
                    params["noc"] = houseNo
                    params["complaintDetails"] = textDetails
                    return params
                }
            }
            VolleySingleton.instance?.addToRequestQueue(stringRequest)

            startActivity(Intent(this, submitted::class.java))
        }
    }
}