package com.example.group1

import android.content.Intent
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.*
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class MainActivity() : AppCompatActivity() {

    private var editTextemail: EditText? = null
    private var editTextpassword: EditText? = null

    constructor(parcel: Parcel) : this() {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextemail = findViewById<EditText>(R.id.email)
        editTextpassword = findViewById<EditText>(R.id.password)
        val btnlogin = findViewById<Button>(R.id.btnlogin)
        val email = findViewById<EditText>(R.id.email)
        var password = findViewById<EditText>(R.id.password)


        btnlogin.setOnClickListener {
            if (email.text.isNullOrBlank() && password.text.isNullOrBlank()) {
                Toast.makeText(this, "Please fill the required fields!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "${email.text} is logged in!", Toast.LENGTH_SHORT).show()
            }
        }
        btnlogin.setOnClickListener {
            loginuser()
            startActivity(Intent(this, reports::class.java))
        }

        val clickSignUp = findViewById(R.id.clickSignUp) as TextView
        clickSignUp.setOnClickListener {
            startActivity(Intent(this, signup::class.java))
        }
    }

    private fun loginuser() {
        var email = editTextemail?.getText().toString()
        var password = editTextpassword?.getText().toString()
        if (!email.equals("") && !password.equals("")) {
            val stringRequest =
                object : StringRequest(Request.Method.POST, EndPoints.URL_LOGIN_USER,
                    Response.Listener<String> { response ->
                        try {
                            val obj = JSONObject(response)
                            Toast.makeText(
                                applicationContext,
                                obj.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        }
                    },
                    Response.ErrorListener { volleyError ->
                        Toast.makeText(
                            applicationContext,
                            volleyError.message,
                            Toast.LENGTH_LONG
                        ).show()
                    }) {
                    @Throws(AuthFailureError::class)
                    override fun getParams(): Map<String, String> {
                        val params = HashMap<String, String>()
                        params["email"] = email
                        params["password"] = password
                        return params
                    }
                }

        }
    }
}