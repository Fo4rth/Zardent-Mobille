package com.example.group1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import org.json.JSONException
import org.json.JSONObject
import java.lang.reflect.Method


class signup : AppCompatActivity() {
    private var editTextfullname: EditText? = null
    private var editTextcontact: EditText? = null
    private var editTextemail: EditText? = null
    private var editTextpassword: EditText? = null

    lateinit var btnsignup: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val btnsignup = findViewById<Button>(R.id.btnsignup)


        btnsignup.setOnClickListener{
            editTextfullname = findViewById<TextView>(R.id.fullname) as EditText?
            editTextcontact = findViewById<TextView>(R.id.contact) as EditText?
            editTextemail = findViewById<TextView>(R.id.email) as EditText?
            editTextpassword = findViewById<TextView>(R.id.password) as EditText?

            val fullname = editTextfullname?.text.toString()
            val contact = editTextcontact?.text.toString()
            val email = editTextemail?.text.toString()
            val password = editTextpassword?.text.toString()


            //creating volley string request
            val stringRequest = object : StringRequest(
                Request.Method.POST, EndPoints.URL_ADD_USER,
                Response.Listener<String> { response ->
                    try {
                        val obj = JSONObject(response)
                        Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError -> Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show() }) {
                @Throws(AuthFailureError::class)
                override fun getParams(): Map<String, String> {
                    val params = HashMap<String, String>()
                    params["fullName"] = fullname
                    params["userEmail"] = email
                    params["password"] = password
                    params["contactNo"] = contact
                    return params
                }
            }
            VolleySingleton.instance?.addToRequestQueue(stringRequest)

            startActivity(Intent(this, reports::class.java))
        }
    }
}

